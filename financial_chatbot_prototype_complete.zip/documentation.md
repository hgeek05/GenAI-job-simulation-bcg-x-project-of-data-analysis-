
# Financial Chatbot Prototype

**Developer:** Hiba Ait Belmoumene  
**Project Phase:** Task 2 – AI-Powered Financial Chatbot  
**Company:** BCG Tech Hub, for GFC

## Overview

This chatbot prototype is a simplified, rule-based conversational agent designed to answer a limited set of financial queries based on previously analyzed financial data (Task 1). The chatbot uses conditional logic to respond to common questions related to Apple’s financial performance.

## Features

- Responds to five predefined financial queries:
  1. Total revenue
  2. Net income change
  3. Total assets
  4. Total liabilities
  5. Cash flow from operating activities

- Basic command-line interaction using Python’s `input()` function
- Graceful handling of unrecognized inputs

## How it Works

- The chatbot reads user input.
- It checks the input against a list of predefined queries using `if-elif-else` statements.
- When a match is found, the chatbot returns the corresponding hardcoded financial insight.
- If the input is not recognized, it informs the user accordingly.

## Technologies Used

- Python (standard libraries only)

## How to Use

1. Run the Python script: `python chatbot.py`
2. Type a question from the predefined list.
3. Type “exit” or “quit” to end the session.

## Limitations

- Only supports a fixed set of questions.
- Does not learn from new interactions or handle natural language variations.
- Only covers Apple’s 2023 financial data.

## Future Improvements

- Integration with real-time financial data
- Natural Language Processing (NLP) for flexible query handling
- Web interface with Flask for broader accessibility

---

*This prototype was developed as part of an AI chatbot project for financial analysis under the guidance of BCG’s Aisha and the GFC initiative.*
