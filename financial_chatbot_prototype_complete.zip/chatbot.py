
def simple_chatbot(user_query):
    if user_query == "What is the total revenue?":
        return "The total revenue for the last reported year was $394.3 billion (Apple, 2023)."
    elif user_query == "How has net income changed over the last year?":
        return "Apple's net income decreased by 2.8% from 2022 to 2023."
    elif user_query == "What are the total assets?":
        return "Apple's total assets for 2023 were $352.583 billion."
    elif user_query == "What are the total liabilities?":
        return "Apple's total liabilities for 2023 were $290.437 billion."
    elif user_query == "What is the cash flow from operating activities?":
        return "Apple's cash flow from operating activities in 2023 was $110.543 billion."
    else:
        return "Sorry, I can only provide information on predefined queries."

# Example interaction
if __name__ == "__main__":
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chatbot: Goodbye!")
            break
        response = simple_chatbot(user_input)
        print(f"Chatbot: {response}")
